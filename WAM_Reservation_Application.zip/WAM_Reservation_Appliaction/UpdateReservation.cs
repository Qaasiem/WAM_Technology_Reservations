﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WAM_Reservation_Appliaction
{
    public partial class UpdateReservation : Form
    {
        public UpdateReservation()
        {
            InitializeComponent();
        }

        SqlConnection connect = new SqlConnection("Server=localhost;Database=WAM_Reservations_DB;Trusted_Connection=True");

        private void UpdateReservation_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0)
            {
                MessageBox.Show("Please enter first name", "First Name Missing",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textBox2.Text.Length == 0)
            {
                MessageBox.Show("Please enter last name", "Last Name Missing",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textBox3.Text.Length == 0)
            {
                MessageBox.Show("Please enter telephone number", "Telephone Number Missing",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textBox3.Text.Length < 10)
            {
                MessageBox.Show("Please enter a valid telephone number", "Telephone Number Invalid",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (comboBox1.Text.Length == 0)
            {
                MessageBox.Show("Please enter a valid telephone number", "Telephone Number Invalid",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (comboBox1.Text.Length == 0)
            {
                MessageBox.Show("Please select a reservation type", "Reservation Type Missing",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (DateTime.Parse(dateTimePicker1.Text) < DateTime.UtcNow)
            {
                MessageBox.Show("Please select a date in the future as your start date", "Start Date Invalid",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (DateTime.Parse(dateTimePicker2.Text) < DateTime.Parse(dateTimePicker1.Text))
            {
                MessageBox.Show("Please select a date later than start date", "End Date Invalid",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                connect.Open();
                SqlCommand command = new SqlCommand("exec dbo.Client_Reservations_Update '" + textBox4.Text + "','" + textBox3.Text + "','" + textBox2.Text + "','" + textBox1.Text + "', '" + comboBox1.Text + "', '" + dateTimePicker1.Text + "', '" + dateTimePicker2.Text + "'",
                    connect);

                command.ExecuteNonQuery();
                connect.Close();
                MessageBox.Show("Reservation Succefully Updated");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HomePage home = new HomePage();
            home.Show();
            Hide();
        }
    }
}
