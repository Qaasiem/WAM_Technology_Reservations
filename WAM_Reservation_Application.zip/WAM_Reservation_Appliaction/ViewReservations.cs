﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WAM_Reservation_Appliaction
{
    public partial class ViewReservations : Form
    {
        public ViewReservations()
        {
            InitializeComponent();
        }

        private void ViewReservations_Load(object sender, EventArgs e)
        {
            DisplayAllRecords();
        }

        SqlConnection connect = new SqlConnection("Server=localhost;Database=WAM_Reservations_DB;Trusted_Connection=True");

        void DisplayAllRecords()
        {
            SqlCommand command = new SqlCommand("exec dbo.Client_Reservations_View", connect);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            dataAdapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HomePage home = new HomePage();
            home.Show();
            Hide();
        }
    }
}
