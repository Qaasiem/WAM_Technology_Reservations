﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WAM_Reservation_Appliaction
{
    public partial class DeleteReservation : Form
    {
        public DeleteReservation()
        {
            InitializeComponent();
        }

        SqlConnection connect = new SqlConnection("Server=localhost;Database=WAM_Reservations_DB;Trusted_Connection=True");

        private void button1_Click(object sender, EventArgs e)
        {
            connect.Open();
            SqlCommand command = new SqlCommand("exec dbo.Client_Reservations_Delete '" + textBox1.Text +"'" ,
                connect);

            command.ExecuteNonQuery();
            connect.Close();
            MessageBox.Show("Reservation Succefully Delete");
        }

        private void DeleteReservation_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            HomePage home = new HomePage();
            home.Show();
            Hide();
        }
    }
}
